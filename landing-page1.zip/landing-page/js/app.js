
//Defining  Global Variables

const navList = document.getElementById('navbar__list');
const listItems = document.getElementsByClassName('listItem');
const sections = document.querySelectorAll('section');
const sectionList = ['Section 1', 'Section 2', 'Section 3', 'Section 4'];

/* Building the navigation with map method in order to create a new array populated with
   the results of calling a provided function on every element in the calling array.
   For each element from our array we are adding a class and attributes. */

function buildNavigation() {
    const navigationItems = sectionList.map((section, index) => {
        const key = `section${index + 1}`;
        const anchor = document.createElement('a');//Creating a new 'a' element
        anchor.innerHTML = section;
        anchor.className ='listItem';//Adding new class
        anchor.setAttribute('data-nav', key);//Setting attributes for each element from the array
        const listItem = document.createElement('li');//creating new 'li' element 
        listItem.appendChild(anchor);
        navList.appendChild(listItem);

    });
}

//This function showa which section is being viewed while scrolling through the page.

function isInViewport(el) {
    let rect = el.getBoundingClientRect();
    return (
        rect.top <= 150 && rect.bottom >= 150
    );
}

// Using for loop to add a new class- active  every time the section is in viewport.

function setActiveClass() {
    for (i = 0; i < sections.length; i++) {
        const currentItem = sections[i];
        const menuItem = listItems[i];
        const isSectionActive = isInViewport(currentItem);
        if (isSectionActive) {
            menuItem.classList.add('your-active-class')
        }
        else {
            menuItem.classList.remove('your-active-class');
        }
    }
}

// Scroll to anchor ID using scrollTO event

function scrollToElement(event) {
    event.preventDefault();
    const itemHTML = event.target.getAttribute('data-nav');
    const section = document.getElementById(itemHTML);
    section.scrollIntoView({ behavior: "smooth" });
}

//Calling setActtiveClass function every time the user scrolls on the webpage

document.addEventListener('scroll', function () {
    setActiveClass();
});

// Build menu 
buildNavigation();

/*Calling scrolltoElement function every time the user is 
 clicking one element from our Array (listItem)*/

Array.from(listItems).forEach(item => {
    item.addEventListener('click', scrollToElement);
});

