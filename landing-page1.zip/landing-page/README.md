# Landing Page Project

Landing Page is a project required by Udacity for graduaton the Frond End Developer course.

## Structure

This project has 3 components:
index.html - the html code was provided by Udacity and contains the standard markup for creating the webpage.
style.css - the Css code  was provided by Udacity  and is used for styling the webpage. In this project I did only few changes, adding styling for the new classes added with javascript.
app.js -the javascript code was created  by me to make the webpage interactive


###Instructions

With javascript I created a dynamic webpage, building interactive navigation menu for each existing section and giving the user the impresion of an interactive page, using events and event functions and array methods. 

